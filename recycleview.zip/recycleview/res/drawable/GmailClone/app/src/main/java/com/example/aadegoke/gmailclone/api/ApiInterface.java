package com.example.aadegoke.gmailclone.api;

import com.example.aadegoke.gmailclone.model.Message;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;



public interface ApiInterface {
    @GET("inbox.json")
    Call<List<Message>> getInbox();
}
