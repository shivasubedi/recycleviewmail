package com.recyclemail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.provider.ContactsContract;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recyclerview);


        List<Mail> mailList=new ArrayList<>();
        mailList.add(new Mail ("softwarica","10:12","mail from college","today regular class start",R.drawable.aa1,R.drawable.ic_star_border_black_24dp));
        mailList.add(new Mail ("notes","02:15","mail form office","today office half time",R.drawable.aa2,R.drawable.ic_star_border_black_24dp));
        mailList.add(new Mail ("shiva subedi","03:10","mail form gmail","you get private mail",R.drawable.aa1,R.drawable.ic_star_border_black_24dp));
        mailList.add(new Mail ("facebook","01:45","mail from facebook","you need to post today",R.drawable.aa2,R.drawable.ic_star_border_black_24dp));
        mailList.add(new Mail ("youtube","08:23","mail from youtube","you get 2000 likes!!",R.drawable.aa1,R.drawable.ic_star_border_black_24dp));


        MailAdaptor Adapter=new MailAdaptor(this, mailList);
        recyclerView.setAdapter(Adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}
