package com.recyclemail;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MailAdaptor  extends RecyclerView.Adapter<MailAdaptor.gmailviewholder>{

    Context mcontext ;

    public MailAdaptor(Context mcontext, List<Mail> mailList) {
        this.mcontext = mcontext;
        this.mailist = mailList;
    }

    List<Mail> mailist;


    @NonNull
    @Override
    public gmailviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.gmail,parent,false);
        return  new gmailviewholder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull gmailviewholder holder, int position) {
        Mail mail= mailist.get(position);
        holder.tvname.setText(mail.getTvname());
        holder.tvdescription1.setText(mail.getTvdescription1());
        holder.tvdescription2.setText(mail.getGetTvdescription2());
        holder.oktime.setText(mail.getTvtime());
        holder.imageView.setImageResource(mail.getImageview());
        holder.starview.setImageResource(mail.getStarview());


    }

    @Override
    public int getItemCount() {
        return mailist.size();

    }

    public  class  gmailviewholder extends RecyclerView.ViewHolder {

        ImageView imageView,starview;
        TextView tvname,tvdescription1,tvdescription2,oktime;

        public gmailviewholder (@NonNull View Itemview){
            super(Itemview);
            imageView= Itemview.findViewById(R.id.icon_profile);
            starview = Itemview.findViewById(R.id.icon_star);
            oktime = Itemview.findViewById(R.id.timestamp);
            tvdescription1=Itemview.findViewById(R.id.txt_primary);
            tvdescription2=Itemview.findViewById(R.id.txt_secondary);
            tvname=Itemview.findViewById(R.id.from);
        }



    }
}
