package com.recyclemail;

public class Mail {
    private String tvname;
    private String tvtime;
    private String tvdescription1;
    private String getTvdescription2;
    private int imageview;
    private int starview;
//make constuctor
    public Mail(String tvname, String tvtime, String tvdescription1, String getTvdescription2, int imageview, int starview) {
        this.tvname = tvname;
        this.tvtime = tvtime;
        this.tvdescription1 = tvdescription1;
        this.getTvdescription2 = getTvdescription2;
        this.imageview = imageview;
        this.starview = starview;
    }

    public String getTvname() {
        return tvname;
    }

    public void setTvname(String tvname) {
        this.tvname = tvname;
    }

    public String getTvtime() {
        return tvtime;
    }

    public void setTvtime(String tvtime) {
        this.tvtime = tvtime;
    }

    public String getTvdescription1() {
        return tvdescription1;
    }

    public void setTvdescription1(String tvdescription1) {
        this.tvdescription1 = tvdescription1;
    }

    public String getGetTvdescription2() {
        return getTvdescription2;
    }

    public void setGetTvdescription2(String getTvdescription2) {
        this.getTvdescription2 = getTvdescription2;
    }

    public int getImageview() {
        return imageview;
    }

    public void setImageview(int imageview) {
        this.imageview = imageview;
    }

    public int getStarview() {
        return starview;
    }

    public void setStarview(int starview) {
        this.starview = starview;
    }
}
